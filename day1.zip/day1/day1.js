let var1,var2,var3,var4;//6.declare four variable without assigning values
let vaar1=10,vaar2=5,vaar3=8,vaar4=9;//7.declare four variable with assignend values
let first_name='Yeabsira';
let last_name='Tesfaye';
let marital_status='single';
let country='Ethiopia';
let age=21;//8.declare variables to store your first name,last name,marital status,country and age in multiple lines
let first_1name='Yeabsira',last_1name='Tesfaye',marital_1status='single',country1='Ethiopia',age1=21;//9.in single line
let myAge=25;
let yourAge=30;//10.declare two variables myAge and yourAge and assign them initial values and log to the browser console  
console.log('I am',myAge,'years old');
console.log('You are',yourAge,'years old')